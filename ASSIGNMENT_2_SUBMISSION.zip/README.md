To compile the program, you can use
clang++ *.cpp -o main -std=c++11

Then, to run the program, you can use
./main test.txt 4

Please replace test.txt with the appropriate text file that you want to test with

Please replace 4 with the number of runways you want to test with

Please make sure there are no empty lines in the test file in the middle of the line or even at the end of the line. Thank You.

Please ignore small mistakes (if there are ) LOL, but the assignment was really complex and i did the best that i could.

Thank You!